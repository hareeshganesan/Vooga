import javax.swing.JFrame;
import java.util.*;
/*public class ChoiceHeadToChange extends Choice{
    private FighterEditorView myViewer;
	public ChoiceHeadToChange(Object obj, Fighter fgt, JFrame p,FighterEditorView viewer) {
		super(obj, fgt, p);
		myViewer=viewer;
		// TODO Auto-generated constructor stub
	}

	@Override
	void update() {
		// TODO Auto-generated method stub
		myViewer.update();
	}

	@Override
	void addElement() {
		// TODO Auto-generated method stub
		for (Head h:(ArrayList<Head>)myModel)
			mylitem.addElement(h.getName());
	}

	@Override
	void setValue(Object s) {
		// TODO Auto-generated method stub
		myFighter.setHead((String)s);
//		System.out.println(myFighter.getName());//
//		System.out.println(myFighter.getHead());//
	}
	
}*/