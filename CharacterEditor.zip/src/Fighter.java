public class Fighter{
	private String name;
	private String head;
	
	public Fighter(){}
	public Fighter(String n){
		name=n;
	}
	public String getName(){
		return name;
	}
	public void setName(String n){
		name=n;
	}
	public String getHead(){
		return head;
	}
	public void setHead(String h){
		head=h;
	}
}